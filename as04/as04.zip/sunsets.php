<!-- Start Header -->
<?php
include("header.php");
?>
<!-- End Header -->

	<?php
    displayImage("<img src='sunset1.jpg' alt='Sunset 1'/>");
    echo displayImage('sunset1.jpg','Sunset 1');
    displayImage("<img src='sunset2.jpg' alt='Sunset 2'/>");
    echo displayImage('sunset2.jpg','Sunset 2');
    displayImage("<img src='sunset3.jpg' alt='Sunset 3'/>");
    echo displayImage('sunset3.jpg','Sunset 3');
  ?>

<!-- Start Footer -->
<?php
include("footer.php");
?>
<!-- End Footer -->