<!-- Start Header -->
<?php
include("header.php");
?>
<!-- End Header -->

	<?php
    displayImage("<img src='autumn1.jpg' alt='Autumn 1'/>");
    echo displayImage('autumn1.jpg','Autumn 1');
    displayImage("<img src='autumn2.jpg' alt='Autumn 2'/>");
    echo displayImage('autumn2.jpg','Autumn 2');
    displayImage("<img src='autumn3.jpg' alt='Autumn 3'/>");
    echo displayImage('autumn3.jpg','Autumn 3');
  ?>

<!-- Start Footer -->
<?php
include("footer.php");
?>
<!-- End Footer -->