<!-- Start Header -->
<?php
include("header.php");
?>
<!-- End Header -->

	<?php
    displayImage("<img src='forest1.jpg' alt='Forest 1'/>");
    echo displayImage('forest1.jpg','Forest 1');
    displayImage("<img src='forest2.jpg' alt='Forest 2'/>");
    echo displayImage('forest2.jpg','Forest 2');
    displayImage("<img src='forest3.jpg' alt='Forest 3'/>");
    echo displayImage('forest3.jpg','Forest 3');
  ?>

<!-- Start Footer -->
<?php
include("footer.php");
?>
<!-- End Footer -->