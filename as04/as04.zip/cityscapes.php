<!-- Start Header -->
<?php
include("header.php");
?>
<!-- End Header -->

	<?php
    displayImage("<img src='city1.jpg' alt='Cityscape 1'/>");
    echo displayImage('city1.jpg','Cityscape 1');
    displayImage("<img src='city2.jpg' alt='Cityscape 2'/>");
    echo displayImage('city2.jpg','Cityscape 2');
    displayImage("<img src='city3.jpg' alt='Cityscape 3'/>");
    echo displayImage('city3.jpg','Cityscape 3');
  ?>

<!-- Start Footer -->
<?php
include("footer.php");
?>
<!-- End Footer -->