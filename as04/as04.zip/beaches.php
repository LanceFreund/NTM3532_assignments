<!-- Start Header -->
<?php
include("header.php");
?>
<!-- End Header -->

	<?php
    displayImage("<img src='beache1.jpg' alt='Beach 1'/>");
    echo displayImage('beach1.jpg','Beach 1');
    displayImage("<img src='beach2.jpg' alt='Beach 2'/>");
    echo displayImage('beach2.jpg','Beach 2');
    displayImage("<img src='beach3.jpg' alt='Beach 3'/>");
    echo displayImage('beach3.jpg','Beach 3');
  ?>

<!-- Start Footer -->
<?php
include("footer.php");
?>
<!-- End Footer -->